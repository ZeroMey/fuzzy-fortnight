#pragma once
#include <lvgl.h>

// Creates Page 2 under `parent`. Returns the page object and sets *out_label to the time label.
lv_obj_t* page_time_create(lv_obj_t* parent, lv_obj_t** out_label);
